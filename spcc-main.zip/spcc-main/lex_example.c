#include <stdio.h>

int main() {
    int a = 5;
    float b = 3.14;
    if (a > 0) {
        b = b + 1;
    }
    return 0;
}